package com.example.android.projecttwo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int rScore = 0;
    int lScore = 0;

    Button oneLeft, twoLeft, threeLeft, oneRight, twoRight, threeRight, reset;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        oneLeft = (Button) findViewById(R.id.oneLeft);
        twoLeft = (Button) findViewById(R.id.twoLeft);
        threeLeft = (Button) findViewById(R.id.threeLeft);
        oneRight = (Button) findViewById(R.id.oneRight);
        twoRight = (Button) findViewById(R.id.twoRight);
        threeRight = (Button) findViewById(R.id.threeRight);
        reset = (Button) findViewById(R.id.reset);

        oneLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(1);
            }
        });
        twoLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(2);
            }
        });
        threeLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(3);
            }
        });
        oneRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(4);
            }
        });
        twoRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(5);
            }
        });
        threeRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(6);
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display(0);
            }
        });
    }

    private void display(int number) {


        if (number == 0) {
            rScore = 0;
            lScore = 0;
        }


        if (number <= 3) {
            lScore += number;

        }
        if (number >= 3) {
            number = number - 3;
            rScore += number;
        }

        TextView quantityTextView = (TextView) findViewById(R.id.scoreLeft);
        quantityTextView.setText("" + lScore);
        TextView quantityTextView2 = (TextView) findViewById(R.id.scoreRight);
        quantityTextView2.setText("" + rScore);

    }


}
