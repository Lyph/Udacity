package com.example.android.projectthree;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by lyphc on 7/12/2016.
 */

public class quizAdapter extends BaseAdapter {

    LayoutInflater layoutInflater;
    Context context;
    ArrayList<quizObject> q;



    public quizAdapter(ArrayList<quizObject> temp, Context context) {

        this.q = temp;
        this.context = context;
        layoutInflater = LayoutInflater.from(context);

    }

    @Override
    public int getCount() {
        return this.q.size();
    }

    @Override
    public Object getItem(int position) {
        return this.q.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        convertView = layoutInflater.inflate(R.layout.quizformat, null);

        TextView question = (TextView) convertView.findViewById(R.id.question);
        RadioButton a = (RadioButton) convertView.findViewById(R.id.a);

        a.setOnClickListener(new View.OnClickListener() {
        //Im pretty sure theres a way to clean this up using switches but it currently works and I don't want to upset the coding gods
            @Override
            public void onClick(View v) {

                if (q.get(position).getCorrect() == 0) {q.get(position).point = 1;}//position for a
                else{q.get(position).point = 0;}//this needs to be included because if the right answer is selected then deselected, it won't reset to 0 automatically
                q.get(position).background= 'a';
            }
        });
        RadioButton b = (RadioButton) convertView.findViewById(R.id.b);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (q.get(position).getCorrect() == 1) {q.get(position).point = 1;}//position for b
                else{q.get(position).point = 0;}
                q.get(position).background= 'b';
            }
        });
        RadioButton c = (RadioButton) convertView.findViewById(R.id.c);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (q.get(position).getCorrect() == 2) {q.get(position).point = 1;}//position for c
                else{q.get(position).point = 0;}
                q.get(position).background= 'c';
            }
        });
        RadioButton d = (RadioButton) convertView.findViewById(R.id.d);
        d.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (q.get(position).getCorrect() == 3) {
                    q.get(position).point = 1;
                }//position for d
                else {
                    q.get(position).point = 0;
                }
                q.get(position).background = 'd';
            }
        });

        for(int i = 0; i<q.size(); i++){ //I really don't like this for loop constantly checking. I can already tell it's ineffecient. (refer to quizObject.java)
            if(q.get(position).background == 'a'){
               a.setChecked(true); b.setChecked(false); c.setChecked(false); d.setChecked(false);
            }
            if(q.get(position).background == 'b') {
                a.setChecked(false); b.setChecked(true); c.setChecked(false); d.setChecked(false);
            }
            if(q.get(position).background == 'c'){
                a.setChecked(false); b.setChecked(false); c.setChecked(true); d.setChecked(false);
            }
            if(q.get(position).background == 'd'){
                a.setChecked(false); b.setChecked(false); c.setChecked(false); d.setChecked(true);            }
        }


        question.setText(q.get(position).getQuestion());
        a.setText(q.get(position).getA());
        b.setText(q.get(position).getB());
        c.setText(q.get(position).getC());
        d.setText(q.get(position).getD());


        return convertView;
    }
}

