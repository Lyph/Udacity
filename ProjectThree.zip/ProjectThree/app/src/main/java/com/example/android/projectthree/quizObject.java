package com.example.android.projectthree;

/**
 * Created by lyphc on 7/12/2016.
 */
public class quizObject {

    String question;
    String A,B,C,D;
    int correct; // tells what position is correct 0 = a etc.
    int point; //allocate points (0 or 1) needed for on click listener
    char background;
    // I previously had the background of radio button change with if state_check is true in the highlight.xml
    // but it would revert to original background if I scrolled out of view and back in.
    // So I implemented a rather inefficent for loop in the adapter to keep state_check true out of view, Any alternative suggestion would be pretty cool


    quizObject(){
        question = "test";
        A = "test";
        B = "test";
        C = "test";
        D = "test";
        correct = -1;
        point = -1000;//if didnt answer question, change this number if you have a quiz over 100 questions
        background = 'z';

    }
    quizObject(String textQ, String textA, String textB, String textC, String textD, int num){
        question = textQ;
        A = textA;
        B = textB;
        C = textC;
        D = textD;
        correct = num;
        point = -1000;
        background = 'z';
    }



    public String getQuestion() {return question;}
    public String getA() {return A;}
    public String getB() {return B;}
    public String getC() {return C;}
    public String getD() {return D;}
    public int getCorrect() {return correct;}


}
